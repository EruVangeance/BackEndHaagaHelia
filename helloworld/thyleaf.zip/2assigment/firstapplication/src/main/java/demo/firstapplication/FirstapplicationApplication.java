package demo.firstapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstapplicationApplication.class, args);
	}

}
